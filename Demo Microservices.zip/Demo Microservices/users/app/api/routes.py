from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from ..crud import user
from ..schemas.user import UserCreate, UserResponse, UserCredentials, UserValidationResponse
from ..db.database import get_db
import uuid
import bcrypt

router = APIRouter()


@router.post("/users/add", response_model=UserResponse)
async def create_user(user_data: UserCreate, db: AsyncSession = Depends(get_db)):
    db_user = await user.get_user_by_email(db, email=user_data.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    return await user.create_user(db=db, user=user_data)


@router.get("/users/all", response_model=list[UserResponse])
async def read_users(db: AsyncSession = Depends(get_db)):
    db_user = await user.get_users(db)
    if db_user is None:
        raise HTTPException(status_code=404, detail="No users found")
    return db_user


@router.post("/users/validate", response_model=UserValidationResponse)
async def validate_user(user_credentials: UserCredentials, db: AsyncSession = Depends(get_db)):
    db_user = await user.get_user_by_email(db, email=user_credentials.email)
    if db_user and bcrypt.checkpw(user_credentials.password.encode('utf-8'), db_user.password_hash.encode('utf-8')):
        return {"is_valid": True, "user_id": str(db_user.user_id), "role": db_user.role}
    return {"is_valid": False}


@router.get("/users/{user_id}", response_model=UserResponse)
async def read_user(user_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    db_user = await user.get_user(db, user_id=user_id)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return db_user
