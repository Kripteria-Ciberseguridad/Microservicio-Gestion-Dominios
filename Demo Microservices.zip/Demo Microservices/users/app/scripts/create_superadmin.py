import asyncio
import os
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text
from app.models.user import User, Role
from app.utils.security import get_password_hash

DATABASE_URL = os.getenv("DATABASE_URL")

engine = create_async_engine(DATABASE_URL, echo=True)
SessionLocal = sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False
)


async def create_superadmin():
    async with SessionLocal() as session:
        query = text("SELECT * FROM users WHERE role='superadmin'")
        result = await session.execute(query)
        existing_superadmin = result.fetchone()
        if existing_superadmin:
            print("Ya existe un superadmin en la base de datos.")
            return

        superadmin = User(
            username="superadmin",
            email="superadmin@atlasix.com",
            password_hash=get_password_hash("SuperAdmin123!"),
            role=Role.SUPERADMIN.value
        )

        session.add(superadmin)
        await session.commit()
        print("Usuario superadmin creado con éxito.")

if __name__ == "__main__":
    asyncio.run(create_superadmin())
