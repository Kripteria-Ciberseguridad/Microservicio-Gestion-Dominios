from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session
from sqlalchemy.future import select
from ..models.user import User
from ..schemas.user import UserCreate, Role
import bcrypt
import uuid


async def create_user(db: AsyncSession, user: UserCreate):
    hashed_password = bcrypt.hashpw(user.password.encode('utf-8'), bcrypt.gensalt())
    hashed_password_str = hashed_password.decode('utf-8')

    db_user = User(
        username=user.username,
        email=user.email,
        password_hash=hashed_password_str,
        role=user.role if user.role else Role.USER
    )
    db.add(db_user)
    await db.commit()
    await db.refresh(db_user)
    return db_user


async def get_user(db: AsyncSession, user_id: uuid.UUID):
    result = await db.execute(select(User).where(User.user_id == user_id))
    return result.scalars().first()


async def get_users(db: AsyncSession):
    result = await db.execute(select(User))
    return result.scalars().all()


async def get_user_by_email(db: AsyncSession, email: str):
    result = await db.execute(select(User).where(User.email == email))
    return result.scalars().first()


def get_user_by_email_sync(db: Session, email: str):
    return db.query(User).filter(User.email == email).first()