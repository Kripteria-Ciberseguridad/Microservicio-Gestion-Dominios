from pydantic import BaseModel, EmailStr
import uuid
from typing import Optional
from enum import Enum

class Role(str, Enum):
    SUPERADMIN = "superadmin"
    ADMIN = "admin"
    USER = "user"

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str
    role: Optional[Role] = None

class UserResponse(BaseModel):
    user_id: uuid.UUID
    username: str
    email: EmailStr
    role: str

    class Config:
        orm_mode = True

class UserCredentials(BaseModel):
    email: str
    password: str

class UserValidationResponse(BaseModel):
    is_valid: bool
    user_id: str | None = None
    role: str