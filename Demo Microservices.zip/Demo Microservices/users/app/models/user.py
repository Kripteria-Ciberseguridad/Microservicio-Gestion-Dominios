from sqlalchemy import Column, String, TIMESTAMP, UUID, Enum
from sqlalchemy.orm import declarative_base
from sqlalchemy.sql import func
import uuid
from enum import Enum as PyEnum

Base = declarative_base()

class Role(PyEnum):
    SUPERADMIN = "superadmin"
    ADMIN = "admin"
    USER = "user"

class User(Base):
    __tablename__ = "users"

    user_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String, unique=True, nullable=False)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String, default=Role.USER.value, nullable=False)
    created_at = Column(TIMESTAMP, server_default=func.now())
    updated_at = Column(TIMESTAMP, server_default=func.now(), onupdate=func.now())