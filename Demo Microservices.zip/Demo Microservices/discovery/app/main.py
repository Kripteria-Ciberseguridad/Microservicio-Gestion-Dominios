from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from .crud import add_domain, get_domains, update_domain, delete_domain
from .utils import validate_token
from .models import Domain
from fastapi import Header

app = FastAPI()

def get_token(authorization: str = Header(...)):
    # Extraemos el token del encabezado y lo validamos
    if not validate_token(authorization):
        raise HTTPException(status_code=401, detail="Unauthorized")
    return authorization

@app.post("/domains/add")
async def add_new_domain(domain: Domain, token: str = Depends(get_token)):
    response = add_domain(domain, client_id="hardcoded_client_id")
    return response

@app.get("/domains/list")
async def list_domains(token: str = Depends(get_token)):
    domains = get_domains(client_id="hardcoded_client_id")
    return domains

@app.put("/domains/update/{domain_id}")
async def update_domain_description(domain_id: str, description: str, token: str = Depends(get_token)):
    response = update_domain(domain_id, description)
    return response

@app.delete("/domains/delete/{domain_id}")
async def delete_domain_by_id(domain_id: str, token: str = Depends(get_token)):
    response = delete_domain(domain_id)
    return response
