from sqlalchemy.future import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.models import Domain, Discovery, Subdomain


async def add_domain(db: AsyncSession, domain_name: str):
    new_domain = Domain(name=domain_name)
    db.add(new_domain)
    await db.commit()
    await db.refresh(new_domain)
    discovery = Discovery(domain_id=new_domain.domain_id, status="added")
    db.add(discovery)
    await db.commit()
    await db.refresh(discovery)


async def get_discovery_status(db: AsyncSession, domain_id: str):
    query = select(Discovery).filter(Discovery.domain_id == domain_id)
    result = await db.execute(query)
    discovery = result.scalars().first()
    if discovery:
        return {"status": discovery.status}
    else:
        raise Exception("Discovery not found")


async def list_subdomains(db: AsyncSession, domain_id: str):
    query = select(Subdomain).filter(Subdomain.domain_id == domain_id)
    result = await db.execute(query)
    return result.scalars().all()
