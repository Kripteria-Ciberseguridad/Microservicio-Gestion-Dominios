import asyncio
from app.core.db import SessionLocal
from app.models.models import Discovery, Subdomain
import subprocess


async def discovery_worker():
    while True:
        async with SessionLocal() as db:
            result = await db.execute(select(Discovery).filter(Discovery.status == "added"))
            discoveries = result.scalars().all()

            for discovery in discoveries:
                discovery.status = "in_progress"
                await db.commit()

                try:
                    result = subprocess.run(["subfinder", "-d", discovery.domain_id], capture_output=True, text=True)
                    subdomains = result.stdout.splitlines()

                    for sub in subdomains:
                        db.add(Subdomain(name=sub, domain_id=discovery.domain_id))
                    discovery.status = "completed"
                except Exception:
                    discovery.status = "error"
                await db.commit()
        await asyncio.sleep(60)
