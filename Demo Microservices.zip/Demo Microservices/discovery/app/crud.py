from pymongo import MongoClient
from bson import ObjectId

client = MongoClient("mongodb://localhost:27017")

db = client["dominios_db"]

async def add_domain(domain_data):
       domain_id = str(ObjectId())
       domain_data['domainId'] = domain_id
       await db.domains.insert_one(domain_data)
       return domain_data