from sqlalchemy import Column, String, TIMESTAMP, ForeignKey, Enum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
import uuid

Base = declarative_base()


class Domain(Base):
    __tablename__ = "domains"
    domain_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String, unique=True, nullable=False)
    created_at = Column(TIMESTAMP, default="now()")
    updated_at = Column(TIMESTAMP, default="now()")
    discoveries = relationship("Discovery", back_populates="domain", cascade="all, delete")


class Discovery(Base):
    __tablename__ = "discoveries"
    discovery_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    domain_id = Column(UUID(as_uuid=True), ForeignKey("domains.domain_id"), nullable=False)
    status = Column(Enum('added', 'in_progress', 'completed', 'error', name="status_enum"), nullable=False)
    created_at = Column(TIMESTAMP, default="now()")
    updated_at = Column(TIMESTAMP, default="now()")
    domain = relationship("Domain", back_populates="discoveries")


class Subdomain(Base):
    __tablename__ = "subdomains"
    subdomain_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    domain_id = Column(UUID(as_uuid=True), ForeignKey("domains.domain_id"), nullable=False)
    name = Column(String, nullable=False)
    created_at = Column(TIMESTAMP, default="now()")
    updated_at = Column(TIMESTAMP, default="now()")
